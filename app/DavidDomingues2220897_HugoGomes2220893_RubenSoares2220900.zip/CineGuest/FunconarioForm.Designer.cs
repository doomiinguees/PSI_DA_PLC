﻿namespace CineGuest
{
    partial class FunconarioForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.bgFuncionario = new System.Windows.Forms.GroupBox();
            this.cbFuncao = new System.Windows.Forms.ComboBox();
            this.btnAddFuncionario = new System.Windows.Forms.Button();
            this.tbCodPostal = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.tbMorada = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.tbLocalidade = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.tbSalario = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.tbNome = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.lbFuncionario = new System.Windows.Forms.ListBox();
            this.btnApagarFuncionario = new System.Windows.Forms.Button();
            this.bgFuncionario.SuspendLayout();
            this.SuspendLayout();
            // 
            // bgFuncionario
            // 
            this.bgFuncionario.Controls.Add(this.cbFuncao);
            this.bgFuncionario.Controls.Add(this.btnAddFuncionario);
            this.bgFuncionario.Controls.Add(this.tbCodPostal);
            this.bgFuncionario.Controls.Add(this.label6);
            this.bgFuncionario.Controls.Add(this.tbMorada);
            this.bgFuncionario.Controls.Add(this.label5);
            this.bgFuncionario.Controls.Add(this.tbLocalidade);
            this.bgFuncionario.Controls.Add(this.label4);
            this.bgFuncionario.Controls.Add(this.tbSalario);
            this.bgFuncionario.Controls.Add(this.label3);
            this.bgFuncionario.Controls.Add(this.label2);
            this.bgFuncionario.Controls.Add(this.tbNome);
            this.bgFuncionario.Controls.Add(this.label1);
            this.bgFuncionario.Location = new System.Drawing.Point(12, 12);
            this.bgFuncionario.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.bgFuncionario.Name = "bgFuncionario";
            this.bgFuncionario.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.bgFuncionario.Size = new System.Drawing.Size(271, 494);
            this.bgFuncionario.TabIndex = 0;
            this.bgFuncionario.TabStop = false;
            // 
            // cbFuncao
            // 
            this.cbFuncao.FormattingEnabled = true;
            this.cbFuncao.Location = new System.Drawing.Point(16, 121);
            this.cbFuncao.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.cbFuncao.Name = "cbFuncao";
            this.cbFuncao.Size = new System.Drawing.Size(231, 24);
            this.cbFuncao.TabIndex = 13;
            // 
            // btnAddFuncionario
            // 
            this.btnAddFuncionario.Location = new System.Drawing.Point(95, 441);
            this.btnAddFuncionario.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnAddFuncionario.Name = "btnAddFuncionario";
            this.btnAddFuncionario.Size = new System.Drawing.Size(151, 23);
            this.btnAddFuncionario.TabIndex = 12;
            this.btnAddFuncionario.Text = "Adicionar Fincionário";
            this.btnAddFuncionario.UseVisualStyleBackColor = true;
            this.btnAddFuncionario.Click += new System.EventHandler(this.btnAddFuncionario_Click);
            // 
            // tbCodPostal
            // 
            this.tbCodPostal.Location = new System.Drawing.Point(16, 394);
            this.tbCodPostal.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tbCodPostal.Name = "tbCodPostal";
            this.tbCodPostal.Size = new System.Drawing.Size(231, 22);
            this.tbCodPostal.TabIndex = 11;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(13, 375);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(92, 16);
            this.label6.TabIndex = 10;
            this.label6.Text = "Codigo Postal";
            // 
            // tbMorada
            // 
            this.tbMorada.Location = new System.Drawing.Point(16, 258);
            this.tbMorada.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tbMorada.Name = "tbMorada";
            this.tbMorada.Size = new System.Drawing.Size(231, 22);
            this.tbMorada.TabIndex = 9;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(13, 240);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(54, 16);
            this.label5.TabIndex = 8;
            this.label5.Text = "Morada";
            // 
            // tbLocalidade
            // 
            this.tbLocalidade.Location = new System.Drawing.Point(16, 326);
            this.tbLocalidade.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tbLocalidade.Name = "tbLocalidade";
            this.tbLocalidade.Size = new System.Drawing.Size(231, 22);
            this.tbLocalidade.TabIndex = 7;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(13, 306);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(75, 16);
            this.label4.TabIndex = 6;
            this.label4.Text = "Localidade";
            // 
            // tbSalario
            // 
            this.tbSalario.Location = new System.Drawing.Point(16, 192);
            this.tbSalario.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tbSalario.Name = "tbSalario";
            this.tbSalario.Size = new System.Drawing.Size(231, 22);
            this.tbSalario.TabIndex = 5;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(13, 174);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(50, 16);
            this.label3.TabIndex = 4;
            this.label3.Text = "Salário";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(13, 101);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(52, 16);
            this.label2.TabIndex = 2;
            this.label2.Text = "Função";
            // 
            // tbNome
            // 
            this.tbNome.Location = new System.Drawing.Point(16, 54);
            this.tbNome.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tbNome.Name = "tbNome";
            this.tbNome.Size = new System.Drawing.Size(231, 22);
            this.tbNome.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(13, 34);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(136, 16);
            this.label1.TabIndex = 0;
            this.label1.Text = "Nome do Funcionário";
            // 
            // lbFuncionario
            // 
            this.lbFuncionario.FormattingEnabled = true;
            this.lbFuncionario.ItemHeight = 16;
            this.lbFuncionario.Location = new System.Drawing.Point(301, 113);
            this.lbFuncionario.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.lbFuncionario.Name = "lbFuncionario";
            this.lbFuncionario.Size = new System.Drawing.Size(675, 260);
            this.lbFuncionario.TabIndex = 1;
            this.lbFuncionario.SelectedIndexChanged += new System.EventHandler(this.lbFuncionario_SelectedIndexChanged);
            // 
            // btnApagarFuncionario
            // 
            this.btnApagarFuncionario.Location = new System.Drawing.Point(821, 452);
            this.btnApagarFuncionario.Name = "btnApagarFuncionario";
            this.btnApagarFuncionario.Size = new System.Drawing.Size(154, 23);
            this.btnApagarFuncionario.TabIndex = 2;
            this.btnApagarFuncionario.Text = "Apagar Funcionáro";
            this.btnApagarFuncionario.UseVisualStyleBackColor = true;
            this.btnApagarFuncionario.Click += new System.EventHandler(this.btnApagarFuncionario_Click);
            // 
            // FunconarioForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1023, 532);
            this.Controls.Add(this.btnApagarFuncionario);
            this.Controls.Add(this.lbFuncionario);
            this.Controls.Add(this.bgFuncionario);
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "FunconarioForm";
            this.Text = "FunconarioForm";
            this.Load += new System.EventHandler(this.FunconarioForm_Load);
            this.bgFuncionario.ResumeLayout(false);
            this.bgFuncionario.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox bgFuncionario;
        private System.Windows.Forms.TextBox tbSalario;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox tbNome;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox tbCodPostal;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox tbMorada;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox tbLocalidade;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button btnAddFuncionario;
        private System.Windows.Forms.ComboBox cbFuncao;
        private System.Windows.Forms.ListBox lbFuncionario;
        private System.Windows.Forms.Button btnApagarFuncionario;
    }
}