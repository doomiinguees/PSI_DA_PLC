DESENVOLVIMENTO DE APLICAÇÕES - CineGest


David Domingues, N.º 2220897
Hugo Gomes, N.º 2220893
Ruben Soares, N.º 2220900
Para executar a aplicação sem o uso do Visual Studio, siga as etapas abaixo:

Abra a pasta do projeto.
Navegue até a pasta "bin" e, em seguida, a pasta "debug".
Localize o executável existente da aplicação.
Dê um duplo clique no executável para executá-lo.
